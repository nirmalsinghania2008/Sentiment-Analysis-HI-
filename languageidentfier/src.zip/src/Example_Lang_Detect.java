
public class Example_Lang_Detect {

	public static void main(String[] args) throws Exception 
	{
		// TODO Auto-generated method stub
		Lang_Detect.initiate();
		System.out.println(Lang_Detect.lang_tag("One farmer died Delhi mein."));
	}
}
